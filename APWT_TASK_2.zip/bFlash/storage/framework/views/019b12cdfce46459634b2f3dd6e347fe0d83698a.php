<?php $__env->startSection('content'); ?>

<html>
	<body>
		<h1>ASSIGNMENT - 01</h1>
		<h2>Islam, Md. Rashedul</h2>
		<h3>19-40559-1</h3>
	</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bFlash\resources\views/home.blade.php ENDPATH**/ ?>