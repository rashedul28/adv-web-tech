
<?php $__env->startSection('content'); ?>

<h1>All products</h1>

<table>
	<tr>
		<th>Product Name</th>
		<th>Product Quantity</th>
		<th>Manufactured Date</th>
		<th>Expired Date</th>
	</tr>
	<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    	<td><a ><?php echo e($p1->productname); ?></a></td>
	    <td><?php echo e($p1->productquantity); ?></td> 
	    <td><?php echo e($p1->manufactureddate); ?></td>
	    <td><?php echo e($p1->expireddate); ?></td>
    </tr>
	

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bFlash\resources\views/productslist.blade.php ENDPATH**/ ?>