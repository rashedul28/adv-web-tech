<html>
	<body>
		<form action="" method="post">
			Username: <input type="text" name="username" value="">
			Password: <input type="password" name="password" value="">
			<input type="submit" name="submit">
			<input type="reset" name="reset">
		</form>
	</body>
</html><?php /**PATH E:\bFlash\resources\views/login.blade.php ENDPATH**/ ?>