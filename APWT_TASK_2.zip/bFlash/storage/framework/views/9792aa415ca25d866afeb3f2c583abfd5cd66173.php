
<?php $__env->startSection('content'); ?>

<form action="" method="POST">
	<?php echo e(@csrf_field()); ?>

	<table>
		<tr>
			<td>Product Name</td>
			<td>
				<input type="text" name="product_name" value="<?php echo e(old('product_name')); ?>"><br>
				<?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		        <span class="text-danger"><?php echo e($message); ?></span><br>
		    	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>

		</tr>
		<tr>
			<td>Product Quantity</td>
			<td>
				<input type="text" name="product_quantity" value="<?php echo e(old('product_quantity')); ?>"><br>
				<?php $__errorArgs = ['product_quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		        <span class="text-danger"><?php echo e($message); ?></span><br>
		    	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td>Manufactured Date</td>
			<td>
				<input type="text" name="manufactured_date" value="<?php echo e(old('manufactured_date')); ?>"><br>
				<?php $__errorArgs = ['manufactured_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		        <span class="text-danger"><?php echo e($message); ?></span><br>
		    	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td>Expired Date</td>
			<td>
				<input type="text" name="expired_date" value="<?php echo e(old('expired_date')); ?>"><br>
				<?php $__errorArgs = ['expired_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		        <span class="text-danger"><?php echo e($message); ?></span><br>
		    	<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</td>
		</tr>
		<tr>
			<td><input type="submit"></td>
			<td><input type="reset"></td>
		</tr>
	</table>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\bFlash\resources\views/addproduct.blade.php ENDPATH**/ ?>