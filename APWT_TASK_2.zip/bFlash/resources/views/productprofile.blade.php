@extends('layouts.main')
@section('content')
<h1>Individual products profile</h1>

	{{$product_name}}
	<!-- {{$product_quantity}}
	{{$manufactured_date}}
	{{$expired_date}} -->

@endsection
