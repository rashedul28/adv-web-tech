@extends('navbar')
@section('content')

<html>
	<body>
		<h1>ASSIGNMENT - 01</h1>
		<h2>Islam, Md. Rashedul</h2>
		<h3>19-40559-1</h3>
	</body>
</html>

@endsection