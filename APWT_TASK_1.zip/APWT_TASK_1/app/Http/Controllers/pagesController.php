<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class pagesController extends Controller
{
    
    function welcome(){
        return view('home');
    }
    function aboutUs(){
    	return view('aboutUs');
    }
    function contuctUs(){
    	return view('contuctUs');
    }
    function ourTeams(){
    	return view('ourTeams');
    }
    function products(){
    	return view('products');
    }
}
