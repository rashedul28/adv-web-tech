<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class productsController extends Controller
{
    
    function products(){
        $products = array();
        for ($i=0; $i < 10; $i++) { 
            $product = array(
                'productId' => $i,
                'productName' => 'P'.$i,
                'manufacture' => '01/01/2022'
            );
            $products[] = (object)$product;
        }

        return view('products')
            ->with('products', $products);
    }
}
