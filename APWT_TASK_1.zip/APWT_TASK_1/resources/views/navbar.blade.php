<html>
	<body>
		<ul>
			<li><a href="/">Home</a></li>
			<li><a href="products">Products</a></li>
			<li><a href="ourTeams">Teams</a></li>
			<li><a href="aboutUs">About Us</a></li>
			<li><a href="contuctUs">Contuct Us</a></li>
		</ul>

		@yield('content')

	</body>
</html>