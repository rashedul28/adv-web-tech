@extends('navbar')
@section('content')
<html>
	<body>
		<h1>About our page.</h1>
	</body>
</html>
@endsection