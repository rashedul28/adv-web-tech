@extends('navbar')
@section('content')
<html>
	<body>
		<h1>This is our home page.</h1>
	</body>
</html>
@endsection