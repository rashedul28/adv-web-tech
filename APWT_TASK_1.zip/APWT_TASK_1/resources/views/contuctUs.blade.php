@extends('navbar')
@section('content')
<html>
	<body>
		<h1>Rech to us.</h1>
	</body>
</html>
@endsection