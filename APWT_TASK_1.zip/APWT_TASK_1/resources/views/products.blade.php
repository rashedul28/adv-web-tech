@extends('navbar')
@section('content')
<html>
	<body>
		<h1>Our products.</h1>

		<table border="1">
			<tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Manufactured Date</th>
			</tr>

				@foreach($products as $i)

					<tr>
						<td>{{$i->productId}}  </td>
						<td>{{$i->productName}}</td>
						<td>{{$i->manufacture}}</td>
					</tr>
					
				@endforeach

		</table>

	</body>
</html>
@endsection