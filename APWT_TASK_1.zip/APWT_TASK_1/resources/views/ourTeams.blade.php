@extends('navbar')
@section('content')
<html>
	<body>
		<h1>Geting know to our team.</h1>
	</body>
</html>
@endsection