
<?php $__env->startSection('content'); ?>
<html>
	<body>
		<h1>Our products.</h1>

		<table border="1">
			<tr>
				<th>Product Id</th>
				<th>Product Name</th>
				<th>Manufactured Date</th>
			</tr>

				<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td><?php echo e($i->productId); ?>  </td>
						<td><?php echo e($i->productName); ?></td>
						<td><?php echo e($i->manufacture); ?></td>
					</tr>
					
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</table>

	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APWT TASK_1\resources\views/products.blade.php ENDPATH**/ ?>