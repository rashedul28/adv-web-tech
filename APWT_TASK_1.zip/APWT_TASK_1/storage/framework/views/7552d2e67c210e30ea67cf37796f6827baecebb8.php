
<?php $__env->startSection('content'); ?>
<html>
	<body>
		<h1>About our page.</h1>
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\olp\olp\resources\views/aboutUs.blade.php ENDPATH**/ ?>