<html>
	<body>
		<ul>
			<li><a href="/">Home</a></li>
			<li><a href="products">Products</a></li>
			<li><a href="ourTeams">Teams</a></li>
			<li><a href="aboutUs">About Us</a></li>
			<li><a href="contuctUs">Contuct Us</a></li>
		</ul>

		<?php echo $__env->yieldContent('content'); ?>

	</body>
</html><?php /**PATH C:\xampp\htdocs\olp\resources\views/navbar.blade.php ENDPATH**/ ?>