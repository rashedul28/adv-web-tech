
<?php $__env->startSection('content'); ?>
<html>
	<body>
		<h1>Geting know to our team.</h1>
	</body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\APWT TASK_1\resources\views/ourTeams.blade.php ENDPATH**/ ?>