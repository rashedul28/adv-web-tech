<html>
    <body>
        <h1>Hello i am laravel</h1>
    </body>
</html><?php /**PATH C:\xampp\htdocs\olp\olp\resources\views/welcome.blade.php ENDPATH**/ ?>